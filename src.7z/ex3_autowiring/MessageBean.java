package ex3_autowiring;

public interface MessageBean {
	public void sayHello();
	
	
}
