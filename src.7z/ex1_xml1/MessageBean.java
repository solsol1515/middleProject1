package ex1_xml1;

public interface MessageBean {
	public void sayHello(String name);
}
